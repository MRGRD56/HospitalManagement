CREATE FUNCTION GetClientByBirthDate (@bd DATE)
RETURNS TABLE
AS RETURN (
	SELECT * FROM Пациент
	WHERE ДатаРождения = @bd)
go

